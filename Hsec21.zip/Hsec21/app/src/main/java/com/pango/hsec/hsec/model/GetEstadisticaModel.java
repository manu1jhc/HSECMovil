package com.pango.hsec.hsec.model;

import java.util.ArrayList;

/**
 * Created by Andre on 01/03/2018.
 */

public class GetEstadisticaModel {
    public ArrayList<EstadisticaModel> Data;
    public int Count;

}
