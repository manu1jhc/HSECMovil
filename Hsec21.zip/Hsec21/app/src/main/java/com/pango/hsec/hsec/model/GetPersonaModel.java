package com.pango.hsec.hsec.model;

import java.util.ArrayList;

/**
 * Created by Andre on 16/01/2018.
 */

public class GetPersonaModel {
    public ArrayList<PersonaModel> Data;
    public int Count;
}
