package com.pango.hsec.hsec.model;

import java.util.ArrayList;

/**
 * Created by Andre on 26/02/2018.
 */

public class GetPerfilCapModel {

    public ArrayList<PerfilCapModel> Data;
    public int Count;
}
