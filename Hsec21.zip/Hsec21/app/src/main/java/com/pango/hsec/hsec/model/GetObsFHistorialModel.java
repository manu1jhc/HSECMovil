package com.pango.hsec.hsec.model;

import java.util.ArrayList;

/**
 * Created by jcila on 10/05/2018.
 */

public class GetObsFHistorialModel {
    public ArrayList<ObsFHistorialModel> Data;
    public int Count;
}
