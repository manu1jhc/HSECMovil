package com.pango.hsec.hsec.model;

/**
 * Created by Andre on 02/02/2018.
 */

public class ObsInspModel {

    public String Correlativo;
    public String CodInspeccion;
    public String CodNivelRiesgo;
    public String Observacion;



}
