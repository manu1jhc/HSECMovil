package com.pango.hsec.hsec.model;

/**
 * Created by Andre on 10/01/2018.
 */

public class PlanModel {

    public String CodAccion;
    public String NroDocReferencia;

    public String CodSolicitadoPor;
    public String SolicitadoPor;
    public String CodActiRelacionada;
    public String CodEstadoAccion;
    public String CodNivelRiesgo;
    public String CodAreaHSEC;
    public String CodReferencia;
    public String CodTipoAccion;
    public String FecComprometidaInicial;
    public String FecComprometidaFinal;
    public String DesPlanAccion;

    public String CodResponsables; //lista, codigo de personas responsables
    public String Responsables; //lista, nombre de personas responsables


    public String CodTabla;
    public String NroAccionOrigen;   //solo para inspecciones = NroDetInspeccion
    public String FechaSolicitud;
    public String Editable;
    public String Estado;
    public String CodTipoObs;






}

/*
    public String CodAccion;
    public String NroDocReferencia;
    public String CodAreaHSEC;
    public String CodNivelRiesgo;
    public String DesPlanAccion;
    public String FechaSolicitud;
    public String CodEstadoAccion;
    public String CodSolicitadoPor;
    public String CodResponsable;
    public String CodActiRelacionada;
    public String CodReferencia;
    public String CodTipoAccion;
    public String FecComprometidaInicial;
    public String FecComprometidaFinal;

    */