package com.pango.hsec.hsec.model;

/**
 * Created by BOB on 08/06/2018.
 */

public class CapCursoMinModel {
    public String CodCurso ;
    public String CodTema ;
    public String Tipo ;

    public String Empresa ;
    public int Duracion ; // minutes
    public String Fecha ;
    public String Recurrence;
}
