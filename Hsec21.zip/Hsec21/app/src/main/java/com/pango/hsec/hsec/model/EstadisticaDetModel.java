package com.pango.hsec.hsec.model;

/**
 * Created by Andre on 05/03/2018.
 */

public class EstadisticaDetModel {
    public  String NroDocReferencia;
    public  String Responsable;
    public  String Descripcion;
    public  String Fecha;
    public  String ResponsableDNI;
    public  String DatosAdicionales;



}
