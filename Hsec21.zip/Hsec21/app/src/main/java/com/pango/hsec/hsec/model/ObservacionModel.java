package com.pango.hsec.hsec.model;


public class ObservacionModel {

    public String CodObservacion;
    public String CodAreaHSEC;
    public String CodNivelRiesgo;
    public String CodObservadoPor;//codigo de la persona
    public String ObservadoPor;
    public String Fecha;
    public String Gerencia;
    public String Superint;
    public String CodUbicacion;
    public String Lugar; //Pagenumber
    public String CodTipo;//Elemperpage
    public String CodSubTipo;
   // public String Fecha_inicio;
    //public String Fecha_fin;

    public String FechaInicio;
    public String FechaFin;
    //public String tipo_obs;



}
