package com.pango.hsec.hsec.record;

/**
 * Created by BOB on 24/06/2018.
 */

public interface ParsedNdefRecord {
    String str();
}
