package com.pango.hsec.hsec.model;

public class CausalidadModel {
    public String codCausa;
    public String codCondicion;
    public String codAnalisisCausa;
    public String desCausa;
    public String desCondicion;
    public String desAnalisisCausa;
    public String comentario;
}
