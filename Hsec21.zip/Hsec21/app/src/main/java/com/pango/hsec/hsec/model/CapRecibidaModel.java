package com.pango.hsec.hsec.model;

/**
 * Created by Andre on 27/02/2018.
 */

public class CapRecibidaModel {

    public String Fecha;
    public String Duracion;
    public String Tema;
    public String Tipo;
    public String TipoTema;
    public String Nota;
    public String Estado;
    public String Vencimiento;



}
