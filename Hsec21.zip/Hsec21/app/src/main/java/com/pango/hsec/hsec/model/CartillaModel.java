package com.pango.hsec.hsec.model;

public class CartillaModel {
    public String CodCartilla;
    public String PeligroFatal;
    public Integer Pendientes;
    public String Estado; //dni
}
