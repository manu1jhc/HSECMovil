package com.pango.hsec.hsec.model;

import java.util.ArrayList;

/**
 * Created by Andre on 26/03/2018.
 */

public class AccionMejoraModel {

    public String Correlativo;
    public String CodAccion;
    public String CodResponsable;
    public String Responsable;
    public String Descripcion;
    public String Fecha;
    public String PorcentajeAvance;
    public String Editable;
    public GetGaleriaModel Files;

}
