package com.pango.hsec.hsec.model;

public class MACuasiAccidenteModel {
    public String CodCuasiAcci;
    public String CodAreaHSEC;
    public String CodTipo;
    public String ObservadoPor;
    public String Gerencia;
    public String Superint;
    public String ClasReal;
    public String ClasPotencial;
    public String ActRelacionada;
    public String GrupRiesgo;
    public String Fecha;
    public String Hora;
    public String CodUbicacion;
    public String CodSubUbicacion;
    public String UbicacionEsp;
    public String Lugar;
    //Detalle
    public String TituIncidente;
    public String TituDetallado;
    public String Turno;
    public String CodContrata;
    public String DesSuceso;
    public String AccioInmediatas;
}
