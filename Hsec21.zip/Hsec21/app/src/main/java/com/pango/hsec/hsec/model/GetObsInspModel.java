package com.pango.hsec.hsec.model;

import java.util.ArrayList;

public class GetObsInspModel {

    public ArrayList<ObsInspModel> Data;
    public int Count;
}
