package com.pango.hsec.hsec.model;

/**
 * Created by jcila on 10/05/2018.
 */

public class ObsFHistorialModel {
        public String Correlativo;
        public String CodObsFacilito;
        public String FechaFin;
        public String Comentario;
        public String Estado;
        public String Fecha;
        public String Persona;
        public String UrlObs;

}
