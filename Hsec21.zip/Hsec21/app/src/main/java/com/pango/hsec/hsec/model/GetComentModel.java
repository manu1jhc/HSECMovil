package com.pango.hsec.hsec.model;

import java.util.ArrayList;

/**
 * Created by Andre on 11/01/2018.
 */

public class GetComentModel {
    public ArrayList<ComentModel> Data;
    public int Count;

}
