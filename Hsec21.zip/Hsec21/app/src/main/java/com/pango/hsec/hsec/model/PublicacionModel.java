package com.pango.hsec.hsec.model;

/**
 * Created by Andre on 15/12/2017.
 */

public class PublicacionModel {

    public String Codigo;
    public String Tipo;
    public String Area;
    public String NivelR;
    public String Fecha;
    public String ObsPor;
    public int Comentarios;
    public String Editable;
    public String Obs;
    public String UrlPrew;
    public String UrlObs;
    public String Estado;
    public String Empresa;

}
