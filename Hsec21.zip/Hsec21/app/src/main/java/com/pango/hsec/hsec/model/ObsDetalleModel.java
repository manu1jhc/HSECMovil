package com.pango.hsec.hsec.model;

/**
 * Created by Andre on 15/02/2018.
 */

public class ObsDetalleModel {

    public String CodObservacion;
    public String CodTipo;
    public String Observacion;
    public String Accion; // cod pet
    public String CodActiRel;
    public String CodHHA;
    public String CodSubEstandar;
    public String CodEstado;
    public String CodError;
    public String StopWork;
    public String CodCorreccion;
    // campos de tarea
    public String ComOpt1;
    public String ComOpt2;
    public String ComOpt3;
}
