package com.pango.hsec.hsec.model;

/**
 * Created by Andre on 26/02/2018.
 */

public class PerfilCapModel {

    public String Tema;
    public String Cumplido;
    public String Tipo;
    public String Nota;
    public String Estado;
    public String Vencimiento;

}
