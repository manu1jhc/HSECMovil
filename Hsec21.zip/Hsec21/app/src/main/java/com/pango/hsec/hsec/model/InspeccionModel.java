package com.pango.hsec.hsec.model;

/**
 * Created by Andre on 24/01/2018.
 */

public class InspeccionModel {

    public String CodInspeccion;
    public String CodTipo ;  //observado por
    public String CodContrata ;
    public String FechaP ;
    public String Fecha ;
    public String Gerencia ;
    public String SuperInt ;
    public String CodUbicacion ;
    public String CodSubUbicacion ;
    public String EquipoInspeccion  ;
    public String PersonasAtendidas ;

    public String Elemperpage ;
    public String Pagenumber ;
    public String Estado ;


}
