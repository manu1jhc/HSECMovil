package com.pango.hsec.hsec.model;

import java.util.ArrayList;

/**
 * Created by Andre on 19/02/2018.
 */

public class GetSubDetalleModel {

    public ArrayList<SubDetalleModel> Data;
    public int Count;
}
