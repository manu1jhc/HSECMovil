package com.pango.hsec.hsec.model;

import com.google.gson.annotations.SerializedName;

import java.lang.reflect.Array;

/**
 * Created by Andre on 12/12/2017.
 */

public class UsuarioModel {
    //@SerializedName("CodUsuario")
    public int CodUsuario;
    public String Codigo_Usuario;
    public String CodPersona;
    public String Nombres;
    public String Sexo;
    public String Email;
    public String NroDocumento;
    public String Cargo;
    public String Area;
    public String Rol;
    public String Empresa;
    public String Tipo_Autenticacion;
    public String Passwd;
    public String Estado;
    public boolean PerfilCap;
    public String FichaCurso;

}
