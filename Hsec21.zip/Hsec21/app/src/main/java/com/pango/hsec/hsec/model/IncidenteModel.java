package com.pango.hsec.hsec.model;

public class IncidenteModel {
    public String CodIncidente;
    public String CodTipo ;  //observado por
    public String CodContrata ;
    public String FechaP ;
    public String Fecha ;
    public String Gerencia ;
    public String SuperInt ;
    public String CodUbicacion ;
    public String CodSubUbicacion ;
    public String EquipoInspeccion  ;
    public String PersonasAtendidas ;
    public String GrupoRiesgo ;
    public String Riesgo ;


    public String Elemperpage ;
    public String Pagenumber ;
    public String Estado ;

}
