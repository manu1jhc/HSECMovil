package com.pango.hsec.hsec.model;

public class ObsComentModel {
    public String CodComentario;
    public String Tipo;
    public String Descripcion;

    public ObsComentModel(){}

    public ObsComentModel(String CodComentario, String Tipo, String Descripcion){

        this.CodComentario = CodComentario;
        this.Tipo = Tipo;
        this.Descripcion = Descripcion;

    }


}
