package com.pango.hsec.hsec.model;

/**
 * Created by BOB on 08/06/2018.
 */

public class CapCursoModel {
    public String CodCurso;
    public String Empresa;
    public String CodTema;
    public String Capacidad;
    public String Tipo;
    public String Area;
    public String Lugar;
    public String Fecha;
    public int Duracion; // minutes
    public String PuntajeTotal;
    public String PuntajeP;
    public String Vigencia;
    public String Expositores;
}
