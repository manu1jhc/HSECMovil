package com.pango.hsec.hsec.model;


public class EstadisticaModel {

    public String Codigo;
    public String Descripcion;
    public String Ejecutados;
    public String Estimados;

}
