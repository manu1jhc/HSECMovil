package com.pango.hsec.hsec.model;

import java.util.ArrayList;

/**
 * Created by jcila on 23/04/2018.
 */

public class GetObsFacilitoModel {
    public ArrayList<ObsFacilitoMinModel> Data;
    public int Count;
}
