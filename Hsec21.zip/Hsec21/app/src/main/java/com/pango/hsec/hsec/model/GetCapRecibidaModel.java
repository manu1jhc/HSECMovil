package com.pango.hsec.hsec.model;

import java.util.ArrayList;

/**
 * Created by Andre on 27/02/2018.
 */

public class GetCapRecibidaModel {

    public ArrayList<CapRecibidaModel> Data;
    public int Count;

}
