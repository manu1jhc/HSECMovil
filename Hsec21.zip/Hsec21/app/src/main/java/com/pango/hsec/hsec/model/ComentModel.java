package com.pango.hsec.hsec.model;

/**
 * Created by Andre on 11/01/2018.
 */

public class ComentModel {
    public String CodComentario;
    public String Nombres;
    public String Comentario;
    public String Fecha;
    public String Estado; //dni


    //https://app.antapaccay.com.pe/HSECWeb/WHSEC_Service/api/media/getAvatar/43054695/fotocarnet.jpg
}
