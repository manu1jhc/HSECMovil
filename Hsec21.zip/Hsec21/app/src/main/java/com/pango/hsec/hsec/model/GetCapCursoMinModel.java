package com.pango.hsec.hsec.model;

import java.util.ArrayList;

/**
 * Created by BOB on 08/06/2018.
 */

public class GetCapCursoMinModel {
    public ArrayList<CapCursoMinModel> Data;
    public int Count;
}
