package com.pango.hsec.hsec.model;

import java.util.ArrayList;

public class GetEstadisticaDetModel {

    public ArrayList<EstadisticaDetModel> Data;
    public int Count;
}
