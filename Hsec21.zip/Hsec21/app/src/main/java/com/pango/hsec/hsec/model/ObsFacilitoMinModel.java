package com.pango.hsec.hsec.model;

/**
 * Created by jcila on 9/05/2018.
 */

public class ObsFacilitoMinModel {
    public String CodObsFacilito;
    public String Tipo;
    public String Observacion;
    public String Estado;
    public String Editable;
    public String Total;
    public String Persona;
    public String Fecha;
    public String UrlObs;
    public String UrlPrew;
    public int TiempoDiffMin;
    public String Empresa;
}
