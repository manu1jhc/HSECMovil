package com.pango.hsec.hsec.model;

import java.util.ArrayList;

/**
 * Created by Andre on 12/03/2018.
 */

public class GetPlanMinModel {

    public ArrayList<PlanMinModel> Data;
    public int Count;
}
