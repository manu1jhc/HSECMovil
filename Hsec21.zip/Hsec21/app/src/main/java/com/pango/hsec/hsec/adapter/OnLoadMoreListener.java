package com.pango.hsec.hsec.adapter;

/**
 * Created by BOB on 11/06/2018.
 */

public interface OnLoadMoreListener {
    void onLoadMore();
}