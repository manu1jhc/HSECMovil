package com.pango.hsec.hsec.model;

public class VerificacionModel {
    public String CodVerificacion;
    public String CodAreaHSEC;
    public String CodNivelRiesgo;
    public String CodVerificacionPor ;//codigo de la persona
    public String ObservadoPor;
    public String Fecha;
    public String Gerencia;
    public String Superint;
    public String CodUbicacion;//Elemperpage
    public String Lugar; //Pagenumber
    public String CodTipo;

    public String StopWork;
    public String Observacion;
    public String Accion;

    public String FechaInicio;
    public String FechaFin;
}
