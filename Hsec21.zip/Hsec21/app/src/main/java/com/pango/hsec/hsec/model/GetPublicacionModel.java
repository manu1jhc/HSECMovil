package com.pango.hsec.hsec.model;

import java.util.ArrayList;

/**
 * Created by Andre on 15/12/2017.
 */

public class GetPublicacionModel {

    public ArrayList<PublicacionModel> Data;
    public int Count;
}
