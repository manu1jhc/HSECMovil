package com.pango.hsec.hsec.model;

/**
 * Created by BOB on 13/04/2018.
 */

public class AccionMejoraMinModel {

    public String Correlativo;
    public String Descripcion;
    public String PorcentajeAvance;
    public String Editable;

    public String UrlObs;
    public String Fecha;
    public String Persona;
}
