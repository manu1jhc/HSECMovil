package com.pango.hsec.hsec.model;

import java.util.ArrayList;

/**
 * Created by Andre on 10/01/2018.
 */

public class GetPlanModel {
    public ArrayList<PlanModel> Data;
    public int Count;
}
