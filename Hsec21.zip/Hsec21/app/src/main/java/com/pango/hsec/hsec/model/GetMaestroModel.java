package com.pango.hsec.hsec.model;

import java.util.ArrayList;

/**
 * Created by BOB on 17/01/2018.
 */

public class GetMaestroModel {
    public ArrayList<Maestro> Data;
    public int Count;
}
