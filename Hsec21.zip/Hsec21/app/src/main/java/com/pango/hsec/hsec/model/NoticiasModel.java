package com.pango.hsec.hsec.model;

/**
 * Created by Andre on 08/02/2018.
 */

public class NoticiasModel {

    public String CodNoticia;
    public String Titulo;
    public String Tipo;
    public String Descripcion;
    public String Autor;
    public String Fecha;
    public String Fecha2;
    public String Estado;
    public String Elemperpage;
    public String Pagenumber;





}
