package com.pango.hsec.hsec.model;

import java.util.ArrayList;

/**
 * Created by Andre on 24/01/2018.
 */

public class GetInspeccionModel {
    public ArrayList<InspeccionModel> Data;
    public int Count;
}
