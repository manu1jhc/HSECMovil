package com.pango.hsec.hsec.model;

/**
 * Created by Andre on 12/03/2018.
 */

public class PlanMinModel {

    public String CodAccion;
    public String FechaSolicitud;
    public String CodSolicitadoPor;
    public String SolicitadoPor;
    public String DesPlanAccion;
    public String CodEstadoAccion;
    public String CodTabla;
    public String CodNivelRiesgo;
    public String Editable;
    public String Estado;
    public String Empresa;

}
