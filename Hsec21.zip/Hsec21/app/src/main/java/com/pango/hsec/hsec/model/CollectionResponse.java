package com.pango.hsec.hsec.model;

import java.util.ArrayList;

public class CollectionResponse<T> {
    public ArrayList<T> Data;
    public int Count;
}
